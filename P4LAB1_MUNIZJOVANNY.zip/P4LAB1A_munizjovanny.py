import turtle

# Set up turtle
t = turtle.Turtle()
t.pensize(3)
t.color("blue")

# Draw square using a for loop
for i in range(4):
    t.forward(100)
    t.right(90)

# Move a bit before drawing triangle
t.penup()
t.forward(150)
t.pendown()

# Draw triangle using a while loop
count = 0
while count < 3:
    t.forward(100)
    t.left(120)
    count += 1

# Keep window open until user clicks
turtle.done()

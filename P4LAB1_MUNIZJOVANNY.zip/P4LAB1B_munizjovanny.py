import turtle

t = turtle.Turtle()
t.pensize(5)
t.color("purple")
t.speed(0)

def draw_J(t, x, top_y, height=120, width=100, radius=25):
    """Draw a J whose top-left starts at (x, top_y)."""
    t.penup(); t.goto(x, top_y); t.pendown()
    t.setheading(0)                 # face east
    t.forward(width)                # top bar
    t.backward(width/2)             # center the stem
    t.setheading(-90)               # face south
    t.forward(height - radius)      # stem
    t.circle(radius, 180)           # bottom hook
    t.penup()

def draw_M(t, x, base_y, height=120, span=100):
    """Draw an M whose left base is at (x, base_y)."""
    left_base = (x, base_y)
    left_top = (x, base_y + height)
    mid_base = (x + span/2, base_y)
    right_top = (x + span, base_y + height)
    right_base = (x + span, base_y)

    t.penup(); t.goto(*left_base); t.pendown()
    t.setheading(90); t.goto(*left_top)     # left vertical
    t.goto(*mid_base)                       # first diagonal
    t.goto(*right_top)                      # second diagonal
    t.goto(*right_base)                     # right vertical
    t.penup()

# Place letters so they don’t overlap
draw_J(t, x=-160, top_y=80)     # J on the right
draw_M(t, x=40,  base_y=-40)    # M on the right

t.hideturtle()
turtle.done()